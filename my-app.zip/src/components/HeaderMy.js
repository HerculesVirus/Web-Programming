import React from "react"
import 'bootstrap/dist/css/bootstrap.css';
import {Button,Navbar,Nav,NavDropdown,Form,FormControl} from "react-bootstrap";
import logo from '../components/images/Watch-logo.PNG';
import Discover from './Discover'



const HeaderMy = () => {
  //const logo = require('');
  const pic_size={
    height : "2.9em",
    width  : "10em",
  }

    return(
      <Navbar bg="light" expand="lg">
          <Navbar.Brand href="/"><img src={logo} style={pic_size} alt="Issue"/></Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll">
            <Nav
              className="mr-auto my-2 my-lg-0"
              style={{ maxHeight: '100px' }}
              navbarScroll
            >
              <Nav.Link href="/">Sales</Nav.Link>
              <Nav.Link href="<Discover/>" >Discover</Nav.Link>
              <Nav.Link href="#action2">Brands</Nav.Link>
              <Nav.Link href="#action2">Ladies</Nav.Link>
              <Nav.Link href="#action2">Men</Nav.Link>
              <Nav.Link href="#action2">Smart Watches</Nav.Link>
              <Nav.Link href="#action2">Jewellery</Nav.Link>
              <Nav.Link href="#action2">Luxury</Nav.Link>
              <Nav.Link href="#action2">My Account</Nav.Link>

              <NavDropdown title="Link" id="navbarScrollingDropdown">
                <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
                <NavDropdown.Item href="#action4">Another action</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action5">Something else here</NavDropdown.Item>
              </NavDropdown>
              {/* <Nav.Link href="#" disabled>
                Link
              </Nav.Link> */}
            </Nav>
            <Form className="d-flex">
              <FormControl
                type="search"
                placeholder="Search"
                className="mr-2"
                aria-label="Search"
              />
              <Button variant="outline-success">Search</Button>
            </Form>
          </Navbar.Collapse>
</Navbar>
      
      //   <nav className="navbar navbar-expand-sm bg-light">
      //   <ul className="navbar-nav">
      //     <li className="nav-item active">
      //       <a className="nav-link" href="#">
      //           <button type="button" class="btn btn-outline-dark" >
      //               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house" viewBox="0 0 16 16">
      //                   <path fill-rule="evenodd" d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
      //                   <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
      //                 </svg>
      //               </button>
      //       </a>
      //     </li>
      //     <li class="nav-item active">
      //       <a class="nav-link" href="#">
      //           <button type="button" class="btn btn-outline-dark">Python</button>
      //       </a>
      //     </li>
      //     <li class="nav-item active">
      //       <a class="nav-link" href="#">
      //           <button type="button" class="btn btn-outline-dark">Java</button>
      //       </a>
      //     </li>
      //     <li class="nav-item active">
      //       <a class="nav-link" href="#">
      //           <button type="button" class="btn btn-outline-dark">C/C++</button>
      //       </a>
      //     </li>
      //   </ul>
      // </nav>
    )
}

export default HeaderMy