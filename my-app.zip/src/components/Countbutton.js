import React, { useState } from "react"



const CountButton = (props) =>{
    const [currentCount , setcurrentCount] = useState(0)
    console.log(props)
    const handleclick = () =>{
        
        
        console.log("Hello T")
        setcurrentCount(currentCount + props.v)
        //document.write(Integer.parseInt(props.incrementby))
    }

    // const dicStyle ={
    //     color : props.color,
    //     background : props.buttoncolor,
    //     borderRadius : "10px",

    // }

    return (
    <div >
        <button  onClick={handleclick}>+{props.v}</button>
        <br/>
         <strong > {currentCount}</strong>  
    </div>
    )

}

export default CountButton