import React from "react"
//import { Card } from 'bootstrap/dist/css/bootstrap.css';

const Cards = (props)=>{
    
    const cards_measure={
        width: "18rem",
        align : "center",
        marginLeft : "7em",

    }
return(

    <div class="d-flex flex-wrap" >
            <div className="card"  style={cards_measure}> 
                <img className="card-img-top" src={props.url} alt="Card image cap"/>
            </div>
        
            <div className="card"  style={cards_measure}> 
                <img className="card-img-top" src={props.url2} alt="Card image cap"/>
            </div>
    
        
            <div className="card" style={cards_measure}> 
                <img className="card-img-top" src={props.url3} alt="Card image cap"/>
            </div>
        
    </div>

 )
}

export default Cards