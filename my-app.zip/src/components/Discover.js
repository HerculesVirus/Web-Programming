import React from "react"

const Discover = () => {
    return (
        <div>
            <h1>new page </h1> 
        </div>
    )
}

export default Discover