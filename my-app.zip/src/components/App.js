import React from "react"
import CountButton from "./Countbutton"
import HeaderMy from "./HeaderMy";
import Cards from "./Cards";
import Carousal from "./ImageSlider";
import { SliderData } from "./SliderData";
import '../components/App.css';


//import { Button } from "bootstrap";
// Put any other imports below so that CSS from your
// components takes precedence over default styles.

const App = () => {
    const strong_tag={
      textAlign : "center",

    }
  
    return(
      <div>
        <HeaderMy />
        <br/>
        <Carousal slides={SliderData}/>
        <br></br>
        <div style={strong_tag}>
              <br/>
                <h2 class="section-header__title">Most Popular Brands</h2>
              <br/>
        </div>
        <Cards  url={"https://i.picsum.photos/id/1004/5616/3744.jpg?hmac=Or7EJnz-ky5bsKa9_frdDcDCR9VhCP8kMnbZV6-WOrY"} url2={"https://images.unsplash.com/photo-1610889672442-5629e6845d17?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"} url3={"https://images.unsplash.com/photo-1523268755815-fe7c372a0349?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80"}/>

        {/* <CountButton  v={1} />
        <CountButton  v={5} />
        <CountButton  v={10}/> */}
      </div>
    )
  }

  export default App